import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { colors } from '@mui/material';

import Dashboard from './components/Dashboard';

import './App.css';

const theme = createTheme({
  palette: {
    primary: {
      main: colors.red[50]
    },
    secondary: {
      main: colors.red[800]
    }
  },
});

function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <div className="App">
        <Router>
          <Routes>
            {/* Login Route */}
            {/* <Route exact path="/login">
						<Login />
					</Route>
					<Route exact path="/register">
						<Register />
					</Route> */}
            {/* Dashboard Route */}
            <Route exact path="/" element={<Dashboard />} />
          </Routes>
        </Router>
      </div>
    </ThemeProvider>
  );
}

export default App;
