import { Box, Drawer, Toolbar, List, ListItem, ListItemButton, ListItemIcon, ListItemText, Button, Divider } from '@mui/material';
import ComputerIcon from '@mui/icons-material/Computer';
import GroupIcon from '@mui/icons-material/Group';
import AddIcon from '@mui/icons-material/Add';

const drawerWidth = 240;

const SideBar = () => {
	return (
		<Drawer
			variant="permanent"
			sx={{
				width: drawerWidth,
				flexShrink: 0,
				[`& .MuiDrawer-paper`]: { width: drawerWidth, boxSizing: 'border-box' },
				bgcolor: "primary"
			}}
		>
			<Toolbar />
			<Box sx={{ overflow: 'auto' }}>
				<Toolbar>
					<Button
						color="secondary"
						disabled={false}
						size="large"
						variant="outlined"
						startIcon={<AddIcon />}
						style={{width: "100%", borderRadius: "25px"}}
					>
						Upload
					</Button>
				</Toolbar>
				<List>
					<ListItem disablePadding>
						<ListItemButton>
							<ListItemIcon>
								<ComputerIcon />
							</ListItemIcon>
							<ListItemText primary='My Drive' />
						</ListItemButton>
					</ListItem>
					<Divider />
					<ListItem disablePadding>
						<ListItemButton>
							<ListItemIcon>
								<GroupIcon />
							</ListItemIcon>
							<ListItemText primary='Users' />
						</ListItemButton>
					</ListItem>
				</List>
			</Box>
		</Drawer>
	);
};

export default SideBar;
