import { Box, Toolbar, Typography } from '@mui/material';

const Main = () => {
	return (
		<Box component="main" sx={{ flexGrow: 1, p: 3 }}>
			<Toolbar />
			<div>
				content
			</div>
		</Box>
	)
};
export default Main;
