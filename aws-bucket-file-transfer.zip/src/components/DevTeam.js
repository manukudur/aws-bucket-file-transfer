export const DevTeam = [
	{
		id: 0,
		name: 'Arnav Gupta',
		imgUrl: 'https://avatars.githubusercontent.com/u/67139196?v=4',
		githubUrl: 'https://github.com/ArnavGuptaaa',
		linkedInUrl: 'https://www.linkedin.com/in/arnavguptaa/',
	},
	{
		id: 1,
		name: 'Sumedh Dixit',
		imgUrl: 'https://avatars.githubusercontent.com/u/54206055?v=4',
		githubUrl: 'https://github.com/sumedhdixit',
		linkedInUrl: 'https://www.linkedin.com/in/sumedhdixit/',
	},
	{
		id: 2,
		name: 'Ratnesh Jain',
		imgUrl: 'https://avatars.githubusercontent.com/u/53041277?v=4',
		githubUrl: 'https://github.com/ratneshjain40',
		linkedInUrl: '#',
	},
];
