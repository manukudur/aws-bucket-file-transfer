import { useState } from 'react';
import { useNavigate } from 'react-router';

import { Box } from '@mui/material';

import SideBar from './SideBar';
import Header from './Header';
import Main from './Main';

const Dashboard = () => {
	// State Variables
	const [userName, setUserName] = useState('');
	const [sideBarOption, setSideBarOption] = useState(0);
	const [isLoggedIn, setIsLoggedIn] = useState(true);
	const [reRender, setReRender] = useState(0);

	const navigate = useNavigate();

	if (isLoggedIn)
		return (
			<Box sx={{ display: 'flex' }}>
				{/* Header */}
				<Header />
				{/* Side Bar */}
				<SideBar />
				{/* Main */}
				<Main />
			</Box>
		);
	else
		return (
			<>
				<h1>Checking Credentials...</h1>
			</>
		);
};

export default Dashboard;